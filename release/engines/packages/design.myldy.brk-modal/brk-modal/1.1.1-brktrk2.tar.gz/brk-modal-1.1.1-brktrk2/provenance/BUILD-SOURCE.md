# BRK Modal corresponding source

Exact BRKTRK source revision: f607f2adcef23a97967fa3a61cbbcdd557c46ed1

https://github.com/myldy20/BRKTRK/tree/f607f2adcef23a97967fa3a61cbbcdd557c46ed1

Source: `engines/brk-modal/` and `abi/`; build and packaging: `scripts/build-modal-wasm.sh`, `scripts/build-modal-factory-presets.sh`, `scripts/build-modal-candidate-package.py` and their referenced scripts. The pinned Emscripten SDK is 4.0.23. BRK Modal is a modified GPLv3 RipplerX work; details and change history are in PROVENANCE.md and the dated repository history at the revision above.
