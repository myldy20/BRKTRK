# Corresponding source

https://github.com/myldy20/BRKTRK/tree/dfd53b08d4508e0d7b5f6fe2bc7abe7278b6250e

Build with Emscripten 4.0.23 from engines/brk-bogie and abi/include. Package with scripts/build-bogie-candidate-package.py.
